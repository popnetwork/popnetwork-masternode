---
name: "🐞 Bug report"
about: Report an issue with this software
title: ''
labels: ''
assignees: ''

---

<!-- DO NOT POST LINKS OR REFERENCES TO COPYRIGHTED CONTENT IN YOUR ISSUE. -->

**What version of popnetwork-masternode are you using?**

**What operating system and version?**

**What happened?**

**What did you expect to happen?**

**Are you willing to submit a pull request to fix this bug?**
