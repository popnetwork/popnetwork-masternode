---
name: "⭐️ Feature request"
about: Request a new feature to be added
title: ''
labels: ''
assignees: ''

---

<!-- DO NOT POST LINKS OR REFERENCES TO COPYRIGHTED CONTENT IN YOUR ISSUE. -->

**What version of popnetwork-masternode are you using?**

**What operating system and version?**

**What problem do you want to solve?**

**What do you think is the correct solution to this problem?**

**Are you willing to submit a pull request to implement this change?**
